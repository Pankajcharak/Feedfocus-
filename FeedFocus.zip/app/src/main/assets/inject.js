(function () {
  if (window.__ffOn) return;
  window.__ffOn = true;
  var SUG = /Sponsored|Suggested for you|Suggested post|Suggested Pages|People you may know|Join group/;
  var FOLLOW = /(^|[\s\u00b7\u2022])Follow([\s\u00b7\u2022]|$)/;
  function cfg() { return window.__ffCfg || {}; }
  function hide(e) {
    if (e && e.style && e.dataset.ff !== '1') {
      e.style.setProperty('display', 'none', 'important');
      e.dataset.ff = '1';
    }
  }
  function apply() {
    var c = cfg(), p = location.pathname;
    if (c.reels && /^\/(reels?|share\/r)(\/|$)/.test(p)) { location.replace('/'); return; }
    if (c.extras && /^\/(explore|marketplace|watch|gaming|groups\/feed)/.test(p)) { location.replace('/'); return; }

    document.querySelectorAll('article,[role="article"]').forEach(function (a) {
      if (a.dataset.ff === '1') return;
      if (a.parentElement && a.parentElement.closest('[role="article"]')) return;
      var head = (a.innerText || '').slice(0, 300);
      if (c.following && (SUG.test(head) || FOLLOW.test(head))) { hide(a); return; }
      if (c.reels && (/Reels and short videos|Suggested reels/.test(head) ||
          a.querySelector('a[href*="/reel/"],a[href*="/reels/"]'))) hide(a);
    });
    if (c.reels) document.querySelectorAll('a[href*="/reels"],[aria-label="Reels"]').forEach(hide);
    if (c.stories) document.querySelectorAll('[aria-label*="Stories"],[aria-label*="stories"],[data-pagelet*="Stories"]').forEach(hide);
    if (c.extras) document.querySelectorAll('a[href^="/explore"],a[href*="/marketplace"],a[href*="/watch"],a[href*="/gaming"]').forEach(hide);
  }

  var over = null;
  function showOverlay(t) {
    over = document.createElement('div');
    over.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#111;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;font:18px sans-serif;text-align:center;padding:24px';
    over.innerHTML = '<div style="font-size:40px">\u2705</div><p>You\u2019re caught up.<br>Scroll limit reached.</p>';
    var b = document.createElement('button');
    b.textContent = 'Back to top';
    b.style.cssText = 'padding:12px 24px;font-size:16px;border-radius:8px;border:0';
    b.onclick = function () {
      over.remove(); over = null;
      window.scrollTo(0, 0);
      if (t && t.scrollTop) t.scrollTop = 0;
    };
    over.appendChild(b);
    document.documentElement.appendChild(over);
  }
  document.addEventListener('scroll', function (e) {
    var c = cfg();
    if (!c.limit || over) return;
    var t = e.target;
    var y = (t === document || t === document.documentElement) ? window.scrollY : (t.scrollTop || 0);
    if (y > c.limit * window.innerHeight) showOverlay(t);
  }, true);

  var timer;
  new MutationObserver(function () {
    clearTimeout(timer);
    timer = setTimeout(apply, 250);
  }).observe(document.documentElement, { childList: true, subtree: true });
  setInterval(apply, 1000);
  apply();
})();
