package com.feedfocus.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    static final String FB = "https://www.facebook.com/?filter=following&sk=following";
    static final String IG = "https://www.instagram.com/?variant=following";
    static final String[] KEYS = {"following", "reels", "stories", "extras", "limit"};
    static final String[] LABELS = {
            "Following only (hide suggested, ads, people you may know)",
            "Block Reels / short videos",
            "Hide Stories",
            "Hide Explore / Marketplace / Watch / Gaming",
            "Scroll limit (stop after ~8 screens)"};
    static final boolean[] DEF = {true, true, true, true, false};

    WebView web;
    SharedPreferences sp;
    String script = "";

    boolean on(String k) {
        for (int i = 0; i < KEYS.length; i++)
            if (KEYS[i].equals(k)) return sp.getBoolean(k, DEF[i]);
        return false;
    }

    String cfgJs() {
        return "window.__ffCfg={following:" + on("following") + ",reels:" + on("reels")
                + ",stories:" + on("stories") + ",extras:" + on("extras")
                + ",limit:" + (on("limit") ? 8 : 0) + "};";
    }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        sp = getSharedPreferences("ff", MODE_PRIVATE);
        try (InputStream in = getAssets().open("inject.js")) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            script = o.toString("UTF-8");
        } catch (IOException ignored) {
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        bar.addView(btn("Facebook", v -> web.loadUrl(FB)), lp);
        bar.addView(btn("Instagram", v -> web.loadUrl(IG)), lp);
        bar.addView(btn("Settings", v -> showSettings()), lp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setUserAgentString(ws.getUserAgentString().replace("; wv", ""));
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String h = u.getHost() == null ? "" : u.getHost();
                String p = u.getPath() == null ? "" : u.getPath();
                boolean ours = h.endsWith("facebook.com") || h.endsWith("instagram.com")
                        || h.endsWith("fbcdn.net") || h.endsWith("fb.com");
                if (!ours) {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                    return true;
                }
                if (on("reels") && p.matches("^/(reels?|share/r)(/.*)?$")) {
                    v.loadUrl(h.contains("instagram") ? IG : FB);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(cfgJs() + script, null);
            }
        });

        if (s == null) web.loadUrl(IG);
        else web.restoreState(s);
    }

    @Override
    protected void onSaveInstanceState(Bundle s) {
        super.onSaveInstanceState(s);
        web.saveState(s);
    }

    void showSettings() {
        boolean[] c = new boolean[KEYS.length];
        for (int i = 0; i < KEYS.length; i++) c[i] = on(KEYS[i]);
        new AlertDialog.Builder(this)
                .setTitle("Feed Focus")
                .setMultiChoiceItems(LABELS, c, (d, i, b) -> sp.edit().putBoolean(KEYS[i], b).apply())
                .setPositiveButton("Apply", (d, w) -> web.reload())
                .show();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
