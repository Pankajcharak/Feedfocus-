package com.feedfocus.app;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.regex.Pattern;

public class FocusService extends AccessibilityService {
    static final String IG = "com.instagram.android";
    static final String FB = "com.facebook.katana";
    static final Pattern SUG = Pattern.compile(
            "Suggested for you|Suggested post|Suggested reels|Sponsored|People you may know|Reels and short videos|Suggested Pages");

    SharedPreferences sp;
    long lastRun, lastScroll, lastAct, lastSeen, selfScrollUntil, blockedUntil;
    int swipes;

    static class Scan {
        boolean reels, explore, sug, isIg;
        int count, bestH;
        AccessibilityNodeInfo home, list;
    }

    @Override
    protected void onServiceConnected() {
        sp = getSharedPreferences("ff", MODE_PRIVATE);
    }

    boolean b(String k, boolean d) {
        return sp.getBoolean(k, d);
    }

    void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (sp == null || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();
        boolean ig = pkg.equals(IG), fb = pkg.equals(FB);
        if (!((ig && b("ig", true)) || (fb && b("fb", true)))) return;

        long now = SystemClock.uptimeMillis();
        if (now - lastSeen > 5 * 60_000L) swipes = 0;
        lastSeen = now;

        // Cooldown after hitting the scroll limit: send user home.
        if (now < blockedUntil) {
            if (now - lastAct > 1500) {
                lastAct = now;
                performGlobalAction(GLOBAL_ACTION_HOME);
                toast("Feed Focus: scroll limit active");
            }
            return;
        }

        // Scroll limit counting (ignores scrolls we triggered ourselves).
        if (e.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED && now > selfScrollUntil) {
            if (now - lastScroll > 600) swipes++;
            lastScroll = now;
            int lim = b("limit", false) ? sp.getInt("limitSwipes", 40) : 0;
            if (lim > 0 && swipes >= lim) {
                swipes = 0;
                blockedUntil = now + sp.getInt("cooldown", 15) * 60_000L;
                lastAct = now;
                performGlobalAction(GLOBAL_ACTION_HOME);
                toast("Feed Focus: scroll limit reached");
                return;
            }
        }

        if (now - lastRun < 350) return;
        lastRun = now;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        Scan s = new Scan();
        s.isIg = ig;
        try {
            walk(root, s, 0);
        } catch (Exception ignored) {
            return;
        }

        if (b("reels", true) && s.reels && now - lastAct > 1200) {
            lastAct = now;
            leave(s);
            toast("Feed Focus: Reels blocked");
            return;
        }
        if (b("explore", false) && s.explore && now - lastAct > 1200) {
            lastAct = now;
            leave(s);
            toast("Feed Focus: Explore blocked");
            return;
        }
        if (b("suggested", true) && s.sug && s.list != null && now - lastAct > 700) {
            lastAct = now;
            selfScrollUntil = now + 900;
            s.list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
        }
    }

    void leave(Scan s) {
        if (s.home == null || !click(s.home)) performGlobalAction(GLOBAL_ACTION_BACK);
    }

    boolean click(AccessibilityNodeInfo n) {
        for (int i = 0; i < 4 && n != null; i++) {
            if (n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            n = n.getParent();
        }
        return false;
    }

    void walk(AccessibilityNodeInfo n, Scan s, int d) {
        if (n == null || d > 40 || s.count++ > 1500) return;
        String id = n.getViewIdResourceName() == null ? "" : n.getViewIdResourceName();
        CharSequence t = n.getText(), cd = n.getContentDescription();
        String txt = (t == null ? "" : t.toString()) + " " + (cd == null ? "" : cd.toString());
        txt = txt.trim();
        boolean shortTxt = txt.length() <= 80;

        if (id.contains("clips_viewer") || id.contains("reel_viewer") || id.contains("reels_viewer"))
            s.reels = true;
        if (n.isSelected()) {
            if (id.endsWith("clips_tab")) s.reels = true;
            if (!s.isIg && shortTxt && txt.startsWith("Reels")) s.reels = true;
            if (id.endsWith("search_tab") || (shortTxt && txt.startsWith("Search and explore")))
                s.explore = true;
        }
        if (s.home == null && (id.endsWith("feed_tab") || (n.isClickable() && txt.equals("Home"))))
            s.home = n;

        if (n.isScrollable() && n.getClassName() != null) {
            String cn = n.getClassName().toString();
            if (cn.contains("RecyclerView") || cn.contains("ListView") || cn.contains("ScrollView")) {
                Rect r = new Rect();
                n.getBoundsInScreen(r);
                if (r.height() > s.bestH) {
                    s.bestH = r.height();
                    s.list = n;
                }
            }
        }
        if (!s.sug && shortTxt && SUG.matcher(txt).find()) {
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            int h = getResources().getDisplayMetrics().heightPixels;
            if (r.height() > 0 && r.top < h * 0.7 && r.bottom > h * 0.12) s.sug = true;
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), s, d + 1);
    }

    @Override
    public void onInterrupt() {
    }
}
