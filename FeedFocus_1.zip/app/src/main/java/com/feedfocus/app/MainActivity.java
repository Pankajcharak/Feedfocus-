package com.feedfocus.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    SharedPreferences sp;
    LinearLayout col;
    TextView status;

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    TextView label(String t, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        v.setPadding(0, dp(14), 0, dp(4));
        col.addView(v);
        return v;
    }

    void sw(String text, String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setTextSize(16);
        s.setChecked(sp.getBoolean(key, def));
        s.setPadding(0, dp(10), 0, dp(10));
        s.setOnCheckedChangeListener((v, c) -> sp.edit().putBoolean(key, c).apply());
        col.addView(s);
    }

    void spinner(String title, String key, int def, int[] vals, String unit) {
        label(title, 14, false);
        Spinner spin = new Spinner(this);
        String[] names = new String[vals.length];
        int sel = 0, cur = sp.getInt(key, def);
        for (int i = 0; i < vals.length; i++) {
            names[i] = vals[i] + " " + unit;
            if (vals[i] == cur) sel = i;
        }
        spin.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        spin.setSelection(sel);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                sp.edit().putInt(key, vals[pos]).apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {
            }
        });
        col.addView(spin);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("ff", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(36), dp(20), dp(36));
        sv.addView(col);
        setContentView(sv);

        label("Feed Focus", 26, true);
        status = label("", 15, false);
        Button open = new Button(this);
        open.setText("Open Accessibility settings");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        col.addView(open);
        label("Turn on Feed Focus under Installed apps. On Android 13+, if it is greyed out: "
                + "Settings > Apps > Feed Focus > \u22EE > Allow restricted settings.", 12, false);

        label("Apps", 18, true);
        sw("Instagram", "ig", true);
        sw("Facebook", "fb", true);

        label("Feed", 18, true);
        sw("Block Reels (sends you back to Home)", "reels", true);
        sw("Skip suggested posts & ads", "suggested", true);
        sw("Block Explore / Search tab", "explore", false);

        label("Scroll limit", 18, true);
        sw("Enable scroll limit", "limit", false);
        spinner("Swipes before stopping", "limitSwipes", 40, new int[]{20, 40, 60, 100, 200}, "swipes");
        spinner("Locked out for", "cooldown", 15, new int[]{5, 15, 30, 60}, "min");
    }

    @Override
    protected void onResume() {
        super.onResume();
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean on = en != null && en.contains(getPackageName() + "/");
        status.setText(on ? "\u2705 Service is ON" : "\u26A0\uFE0F Service is OFF \u2013 enable it to start filtering");
    }
}
